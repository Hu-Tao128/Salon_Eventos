import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        
        
        String Validar;
        int Opcion = 0;
        
        do {
            
            System.out.println("================================");
            System.out.println("|              Menu             |");
            System.out.println("|-------------------------------|");
            System.out.println("|       1) Iniciar Sesion       |");
            System.out.println("|-------------------------------|");
            System.out.println("|         2) Registrarse        |");
            System.out.println("|-------------------------------|");
            System.out.println("|   3) Ver Servicios y Salones  |");
            System.out.println("|-------------------------------|");
            System.out.println("|         4) Administrador      |");
            System.out.println("|-------------------------------|");
            System.out.println("|            5) Salir           |");
            System.out.println("|-------------------------------|");
            System.out.println("================================");

            Validar = Leer.next();
            //popn variable string y co try catch validas si se puede convertir a entero

            try {
                Opcion = Integer.parseInt(Validar);


            switch (Opcion) {
                case 1:
                InsertarDatos data = new InsertarDatos();
                data.insertarDatosSalon();
                break;
                    
                case 2:
                    System.out.println("Bienvenido al sisema para registrarse en nuestro salon de eventos /nombre/");
        
                    break;

                case 3:
                    InsertarDatos datos = new InsertarDatos();
                    datos.insertarDatosSalon();
                    break;

                case 4:
                    Scanner ver = new Scanner(System.in);
                    String admin = "papa";
                    String admin1 = "";

                    String  pass = "no";
                    String pass1 = "no";
                    System.out.println("Bienvenido a la vista de administrador");

                    
                        do{
                            System.out.println("Ingrese la contraseña para ingresar a la vista de administrador");
                            admin1 = ver.nextLine();
                            
                            if(!admin1.equals(admin)){
                                System.out.println("Quieres salir de este apartado? (si/no)");
                                pass = ver.nextLine();
                            }
                        }while (!admin1.equals(admin) && pass.equals(pass1));

                        if(admin1.equals(admin)){
                            System.out.println("Inicio de sesion exitoso");

                            administradorMain data1 = new administradorMain();
                            data1.menuAdministrador();
                        }
                    break;

                    case 5:
                        System.out.println("Software finalizado");
                    break;
            
                default:
                    System.out.println("Por favor use una de las opciones anteriores");
                    break;
            }

            } catch (Exception e) {
                System.out.println("Ingrese Numeros por favor");
            }

        } while (Opcion != 5);
        
        /*InsertarDatos dato = new InsertarDatos();
        dato.insertarDatosSalon();*/
    }

}
